
##i = 1

##print("I have " + str(i) + " apple")


def superfun(fun, arg1, arg2):
    return fun(arg1, arg2)

print(superfun(min,1,2))
